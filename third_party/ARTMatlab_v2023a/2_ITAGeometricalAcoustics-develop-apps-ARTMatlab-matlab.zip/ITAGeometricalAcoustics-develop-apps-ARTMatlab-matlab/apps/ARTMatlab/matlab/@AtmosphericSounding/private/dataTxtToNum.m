function dataNum = dataTxtToNum(dataTxt)
%Converts the data in table/txt form to numeric data

% -------------------------------------------------------------------------
%                        ____  __________  _______
%                       //  / //__   ___/ //  _   |
%                      //  /    //  /    //  /_|  |
%                     //  /    //  /    //  ___   |
%                    //__/    //__/    //__/   |__|
%
% -------------------------------------------------------------------------
%                  ARTMatlab - ITAGeometricalAcoustics
%        (c) Copyright Institute of Technical Acoustics (ITA)
%  This file is part of the ARTMatlab application. Some rights reserved.
% You can find the license in the LICENSE.md file in the ARTMatlab folder.
%--------------------------------------------------------------------------

tmpFilename = 'tmp';
writeTextLinewise(dataTxt, tmpFilename);
dataNum  = dlmread(tmpFilename);
delete(tmpFilename);
end