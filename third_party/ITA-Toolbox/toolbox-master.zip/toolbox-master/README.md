# ITA-Toolbox
Welcome to the ITA-Toolbox, an open source MATLAB toolbox for acoustics developed by the [Institute of Technical Acoustics](http://www.akustik.rwth-aachen.de/) of the [RWTH Aachen University](http://www.rwth-aachen.de/).

[Project Website](http://www.ita-toolbox.org)

[Wiki](https://git.rwth-aachen.de/ita/toolbox/wikis/home)

[Setup Instructions](Getting_Started.txt)