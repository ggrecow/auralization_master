package ita.listeningTestGUI;

public class ControllerInput_keymap_windows extends ControllerInput_keymap 
{
	static protected int controllerFingerprint = 522412925;
	
	public ControllerInput_keymap_windows()
	{
		controllerFingerprint =  522412925;
		
		startButton = 402811501;
		aButton = 402811189;
		bButton = 402811228;
		xButton = 402811150;
		yButton = 402811267;
		xAxis = 1663653298;
		yAxis = 1916558489;
		zAxis = -2125503616;
		zRotation = -1900364;
		
		lbButton = 402811306;
		rbButton = 402811345;
		ltButton = 402811384;
		rtButton = 402811423;
		
	}
	
	static public int getFingerprint(){
		return controllerFingerprint;
	}
}
