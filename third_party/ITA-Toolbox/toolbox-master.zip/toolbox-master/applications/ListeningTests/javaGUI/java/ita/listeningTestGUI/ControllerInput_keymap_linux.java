package ita.listeningTestGUI;

public class ControllerInput_keymap_linux extends ControllerInput_keymap
{
	static protected int controllerFingerprint = -1123851730; // on x: -372416597
	public ControllerInput_keymap_linux()
	{
		controllerFingerprint = -372416597;
		startButton = -1448886581;
		aButton = -281906524;
		bButton = -281906485;
		xButton = -281905627;
		yButton = -281905588;
		xAxis = -281904379;
		yAxis = -281904340;
		zAxis = -281766553;
		zRotation = -281766514;
		
	}
	
	static public int getFingerprint(){
		return controllerFingerprint;
	}
	
	
}
