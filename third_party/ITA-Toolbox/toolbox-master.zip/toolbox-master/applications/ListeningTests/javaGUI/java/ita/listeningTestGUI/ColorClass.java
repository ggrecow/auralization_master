package ita.listeningTestGUI;

public class ColorClass {
	public float[] colorArray = new float[4];
	
	public ColorClass(float r, float g, float b, float alpha)
	{
		colorArray[0] = r;
		colorArray[1] = g;
		colorArray[2] = b;
		colorArray[3] = alpha; //alpha
	}

}
