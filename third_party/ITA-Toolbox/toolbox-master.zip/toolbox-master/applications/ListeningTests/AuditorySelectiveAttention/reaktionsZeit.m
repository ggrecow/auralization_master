function reaktionsZeit(antwort,congruence)

% <ITA-Toolbox>
% This file is part of the application ListeningTests for the ITA-Toolbox. All rights reserved.
% You can find the license for this m-file in the application folder.
% </ITA-Toolbox>

    if antwort ==1  %richtige Antwort
        if congruence==1
            
        elseif
            
            
        end
        
        
    elseif antwort ==0  %falsche Antwort
       if congruence==1
            
        elseif
            
            
        end 
    end
    
    
    
end