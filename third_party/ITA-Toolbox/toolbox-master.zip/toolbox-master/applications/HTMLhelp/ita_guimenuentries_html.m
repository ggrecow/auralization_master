function itamenu = ita_guimenuentries_html()
% ITA_GUIMENUENTRIES_ROOMACOUSTICS - Defines Room Acoustics menu entries

% <ITA-Toolbox>
% This file is part of the application HTMLhelp for the ITA-Toolbox. All rights reserved.
% You can find the license for this m-file in the application folder.
% </ITA-Toolbox>


idx = 1;
itamenu{idx}.type = 'function';
itamenu{idx}.text = 'Generate Documentation';
itamenu{idx}.parent = 'Help';
itamenu{idx}.separator = true;
end