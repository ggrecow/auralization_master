function res = ita_preferences_vibrometer()

% <ITA-Toolbox>
% This file is part of the application Vibrometer for the ITA-Toolbox. All rights reserved. 
% You can find the license for this m-file in the application folder. 
% </ITA-Toolbox>


res = {   'laserControllerComPort','noDevice','str_comPort','Laser COM Port (Controller)','Choose available Comport',2;...
    'laserInterfaceComPort','noDevice','str_comPort','Laser COM Port (Interface)','Choose available Comport',2;...
    };