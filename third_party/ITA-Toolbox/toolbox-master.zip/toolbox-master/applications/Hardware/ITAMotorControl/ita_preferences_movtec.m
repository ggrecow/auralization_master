function res = ita_preferences_movtec()
% ITA_PREFERENCES_MOVTEC - preferences for movtec

% <ITA-Toolbox>
% This file is part of the application Movtec for the ITA-Toolbox. All rights reserved. 
% You can find the license for this m-file in the application folder. 
% </ITA-Toolbox>


res = {    'movtecComPort','noDevice','str_comPort','Movtec COM Port','Choose available Comport',2;...
};