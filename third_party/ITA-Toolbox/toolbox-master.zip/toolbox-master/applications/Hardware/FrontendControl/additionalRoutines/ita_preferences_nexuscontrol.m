function res = ita_preferences_nexuscontrol()
% ITA_PREFERENCES_NEXUSCONTROL - preferences for nexus

% <ITA-Toolbox>
% This file is part of the application RoboAurelioModulITAControl for the ITA-Toolbox. All rights reserved.
% You can find the license for this m-file in the application folder.
% </ITA-Toolbox>

res = {    'nexusComPort','noDevice','str_comPort','Nexus COM Port','Choose available Comport',2;...
    };