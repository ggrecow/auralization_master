--------------------
       README
--------------------

Die mex Datei ITAPolhemus.mex32 ben�tigt folgende zus�tzliche Dateien:

- ITADeviceDrivers.dll
- s�mtliche VistaCoreLibs release DLLs

Zum Initialisieren werden folgende Dateien ben�tigt

- eine Konfigurationsdatei, als Vorlage kann die PolhemusTracker.ini benutzt werde

Der Tracker ben�tigt zum initialisieren ein wenig Zeit. Manchmal klappt es trotzdem nicht.
Sollte ein erneuter Versuch den Tracker wieder nicht zum Laufen bringen, kann ein Neustart
des Polhemus Besserung bringen.