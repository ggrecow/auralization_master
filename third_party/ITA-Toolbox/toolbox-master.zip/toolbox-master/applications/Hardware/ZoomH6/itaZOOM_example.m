zoom_session_data_path = 'D:\Users\stienen\Sciebo\ITA\Projekte\Virtual Reality\ITA_FrontYard\recordings\Zoom_H6\ZOOM0002';

zobj = itaZOOMSession( zoom_session_data_path )


