function [] = ita_laboratory_v2()
% this function is built for ITA_Laboratory_V2 and opens the related GUI

% <ITA-Toolbox>
% This file is part of the application Laboratory for the ITA-Toolbox. All rights reserved.
% You can find the license for this m-file in the application folder.
% </ITA-Toolbox>

v2gui;

end